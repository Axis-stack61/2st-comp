using System;
using System.Collections.Generic;
using MelonLoader;
using UnityEngine;
using UnityEngine.XR;

[assembly: MelonInfo(typeof(TimeStopHostStatic.TimeStopMod), "Time Stop Host (Static Prototype)", "0.3.0", "Source prototype")]

namespace TimeStopHostStatic
{
    // A scheduling shell, not a working Fusion restraint mod until the adapter is supplied.
    public sealed class TimeStopMod : MelonMod
    {
        private const float DurationSeconds = 6f;
        private const float CooldownSeconds = 5f;
        // Slightly more than 250 ms: no more than 4 operations in any rolling second.
        // Conservatively rate-limit removals as well as additions.
        private const float ConstraintIntervalSeconds = 0.26f;
        private const int MaxReleaseAttempts = 3;

        private enum Phase { Idle, Applying, Holding, Releasing }

        private sealed class Job
        {
            internal readonly FusionStaticAdapter.RemotePlayer Player;
            internal readonly FusionStaticAdapter.BodyPart Part;
            internal Job(FusionStaticAdapter.RemotePlayer player, FusionStaticAdapter.BodyPart part)
            {
                Player = player;
                Part = part;
            }
        }

        private sealed class OwnedConstraint
        {
            internal readonly Job Job;
            internal readonly IDisposable Handle;
            internal int ReleaseAttempts;
            internal OwnedConstraint(Job job, IDisposable handle)
            {
                Job = job;
                Handle = handle;
            }
        }

        private readonly List<Job> _jobs = new List<Job>();
        private readonly List<OwnedConstraint> _owned = new List<OwnedConstraint>();
        private readonly Dictionary<string, int> _partsByPlayer = new Dictionary<string, int>();
        private Phase _phase = Phase.Idle;
        private int _nextJob;
        private int _failedReleases;
        private bool _wasVrPressed;
        private bool _menuReady;
        private float _nextOperationAt;
        private float _endAt;
        private float _readyAt;
        private float _nextMenuAttempt;

        public override void OnInitializeMelon()
        {
            MelonLogger.Msg("Sequential Static time-stop prototype loaded. No Fusion constraints " +
                "are created until verified FusionStaticAdapter callbacks are installed.");
        }

        public override void OnUpdate()
        {
            float now = Time.unscaledTime;
            if (!_menuReady && now >= _nextMenuAttempt)
            {
                _menuReady = BoneMenuBridge.TryRegister(Toggle, Resume);
                _nextMenuAttempt = now + 5f;
            }

            bool pressed = RightHandCombo();
            bool trigger = pressed && !_wasVrPressed;
            _wasVrPressed = pressed;
            if (Input.GetKeyDown(KeyCode.F7) || trigger) Toggle();

            if (_phase == Phase.Idle) return;
            try
            {
                if (_phase != Phase.Releasing && !FusionStaticAdapter.IsHost())
                {
                    MelonLogger.Warning("Host authority lost; beginning cleanup.");
                    BeginRelease();
                }
                if (_phase == Phase.Applying && now >= _nextOperationAt) ApplyNext(now);
                else if (_phase == Phase.Holding && now >= _endAt) BeginRelease();
                else if (_phase == Phase.Releasing && now >= _nextOperationAt) ReleaseNext(now);
            }
            catch (Exception e)
            {
                MelonLogger.Warning("Time stop operation failed: " + e.Message);
                BeginRelease();
            }
        }

        private void Toggle()
        {
            if (_phase == Phase.Applying || _phase == Phase.Holding) { BeginRelease(); return; }
            if (_phase == Phase.Releasing) return; // Wait until cleanup is finished.
            if (Time.unscaledTime < _readyAt) return;
            StartSequentialFreeze();
        }

        private void StartSequentialFreeze()
        {
            if (!FusionStaticAdapter.IsReady)
            {
                MelonLogger.Warning("No verified Fusion/Static Constrainer adapter is installed.");
                return;
            }
            try
            {
                if (!FusionStaticAdapter.IsHost())
                {
                    MelonLogger.Warning("Time stop requires the authoritative Fusion host.");
                    return;
                }

                IReadOnlyList<FusionStaticAdapter.RemotePlayer> players = FusionStaticAdapter.GetOthers();
                if (players == null) throw new InvalidOperationException("Fusion player list unavailable.");
                if (players.Count == 0) { MelonLogger.Msg("No remote players to freeze."); return; }

                // Validate the entire snapshot before creating any constraint.
                var snapshot = new List<Job>();
                var seenPlayers = new HashSet<string>();
                foreach (FusionStaticAdapter.RemotePlayer player in players)
                {
                    if (player == null || !seenPlayers.Add(player.Id))
                        throw new InvalidOperationException("Invalid/duplicate player ID in Fusion snapshot.");
                    IReadOnlyList<FusionStaticAdapter.BodyPart> parts = FusionStaticAdapter.GetBodyParts(player);
                    if (parts == null || parts.Count == 0)
                        throw new InvalidOperationException("No constrainable parts found for " + player.Name);
                    var seenParts = new HashSet<string>();
                    foreach (FusionStaticAdapter.BodyPart part in parts)
                    {
                        if (part == null || !seenParts.Add(part.Id))
                            throw new InvalidOperationException("Invalid/duplicate body part for " + player.Name);
                        snapshot.Add(new Job(player, part));
                    }
                }

                _jobs.Clear();
                _jobs.AddRange(snapshot);
                _nextJob = 0;
                _failedReleases = 0;
                _partsByPlayer.Clear();
                _nextOperationAt = Time.unscaledTime;
                _phase = Phase.Applying;
                MelonLogger.Msg("Applying " + _jobs.Count + " Static constraints to " + players.Count +
                    " players, one player at a time, at most four operations per second.");
            }
            catch (Exception e)
            {
                MelonLogger.Warning("Could not prepare time stop: " + e.Message);
            }
        }

        private void ApplyNext(float now)
        {
            if (_nextJob >= _jobs.Count) { StartHolding(now); return; }
            Job job = _jobs[_nextJob];
            IDisposable handle = FusionStaticAdapter.TryConstrain(job.Player, job.Part);
            if (handle == null)
                throw new InvalidOperationException("Could not create Static constraint for " +
                    job.Player.Name + " / " + job.Part.Name);
            _owned.Add(new OwnedConstraint(job, handle));
            _nextJob++;
            _nextOperationAt = now + ConstraintIntervalSeconds;

            int done = _partsByPlayer.TryGetValue(job.Player.Id, out int previous) ? previous + 1 : 1;
            _partsByPlayer[job.Player.Id] = done;
            if (_nextJob == _jobs.Count || _jobs[_nextJob].Player.Id != job.Player.Id)
                MelonLogger.Msg("Finished " + job.Player.Name + ": " + done + " body-part constraints.");
            if (_nextJob == _jobs.Count) StartHolding(now);
        }

        private void StartHolding(float now)
        {
            _phase = Phase.Holding;
            _endAt = now + DurationSeconds;
            MelonLogger.Msg("All target players processed. Six-second hold begins now.");
        }

        private void Resume()
        {
            if (_phase != Phase.Idle) BeginRelease();
        }

        private void BeginRelease()
        {
            if (_phase == Phase.Idle || _phase == Phase.Releasing) return;
            _phase = Phase.Releasing;
            // The rate budget carries over from the last creation; no burst on cancellation.
            if (_owned.Count == 0) { FinishRelease(); return; }
            MelonLogger.Msg("Time stop ending; releasing " + _owned.Count +
                " restraints sequentially (maximum four operations per second).");
        }

        private void ReleaseNext(float now)
        {
            if (_owned.Count == 0) { FinishRelease(); return; }
            OwnedConstraint last = _owned[_owned.Count - 1];
            try
            {
                last.Handle.Dispose(); // The adapter must remove ONLY this constraint.
                _owned.RemoveAt(_owned.Count - 1);
            }
            catch (Exception e)
            {
                last.ReleaseAttempts++;
                MelonLogger.Warning("Release failed for " + last.Job.Player.Name + " / " +
                    last.Job.Part.Name + " (attempt " + last.ReleaseAttempts + "): " + e.Message);
                if (last.ReleaseAttempts >= MaxReleaseAttempts)
                {
                    _owned.RemoveAt(_owned.Count - 1);
                    _failedReleases++;
                }
            }
            _nextOperationAt = now + ConstraintIntervalSeconds;
            if (_owned.Count == 0) FinishRelease();
        }

        private void FinishRelease()
        {
            _phase = Phase.Idle;
            _readyAt = Time.unscaledTime + CooldownSeconds;
            _jobs.Clear();
            _partsByPlayer.Clear();
            _nextJob = 0;
            if (_failedReleases > 0)
                MelonLogger.Error("Time stop ended with " + _failedReleases +
                    " restraints whose removal COULD NOT be confirmed. Check the lobby before using again.");
            else
                MelonLogger.Msg("Time stop ended; all temporary restraints removed.");
        }

        public override void OnDeinitializeMelon()
        {
            // No further frames are guaranteed at unload, so only best-effort cleanup is possible.
            // This emergency path cannot guarantee the normal four-per-second removal budget.
            foreach (OwnedConstraint owned in _owned)
            {
                try { owned.Handle.Dispose(); }
                catch (Exception e) { MelonLogger.Warning("Emergency release failed: " + e.Message); }
            }
            _owned.Clear();
            _phase = Phase.Idle;
        }

        private static bool RightHandCombo()
        {
            InputDevice controller = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
            if (!controller.isValid) return false;
            return controller.TryGetFeatureValue(CommonUsages.gripButton, out bool grip) && grip
                && controller.TryGetFeatureValue(CommonUsages.primaryButton, out bool primary) && primary;
        }
    }
}
