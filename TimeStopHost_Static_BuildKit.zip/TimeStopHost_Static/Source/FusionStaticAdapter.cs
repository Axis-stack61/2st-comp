using System;
using System.Collections.Generic;

namespace TimeStopHostStatic
{
    // Game-version-specific boundary; supply verified BONELAB/Fusion methods.
    // No callback below is implemented by this prototype.
    public static class FusionStaticAdapter
    {
        public sealed class RemotePlayer
        {
            public readonly string Id;
            public readonly string Name;
            public RemotePlayer(string id, string name)
            {
                if (string.IsNullOrEmpty(id)) throw new ArgumentException("Player ID required", nameof(id));
                Id = id;
                Name = name ?? id;
            }
        }

        public sealed class BodyPart
        {
            public readonly string Id;
            public readonly string Name;
            // The real implementation must resolve the native body part from this ID.
            public BodyPart(string id, string name)
            {
                if (string.IsNullOrEmpty(id)) throw new ArgumentException("Body-part ID required", nameof(id));
                Id = id;
                Name = name ?? id;
            }
        }

        public static Func<bool> IsHostResolver;

        // Must return a snapshot of remote players only (never the activating host).
        public static Func<IReadOnlyList<RemotePlayer>> OtherPlayersResolver;

        // Return a snapshot of the relevant, distinct constrainable parts of ONE remote player.
        // Do not include camera/HMD transforms or parts which cannot accept Static constraints.
        public static Func<RemotePlayer, IReadOnlyList<BodyPart>> BodyPartsResolver;

        // EXACTLY ONE game-supported, replicated Static constraint per invocation.
        // On failure it MUST leave zero constraints; on success the IDisposable removes ONLY
        // the constraint created by this invocation. No bulk/all-body implementation here.
        // The remote unmodded player's ability to move must still be verified in-game.
        public static Func<RemotePlayer, BodyPart, IDisposable> CreateStaticConstraintResolver;

        public static bool IsReady => IsHostResolver != null
            && OtherPlayersResolver != null
            && BodyPartsResolver != null
            && CreateStaticConstraintResolver != null;

        public static bool IsHost() => IsReady && IsHostResolver();
        public static IReadOnlyList<RemotePlayer> GetOthers() => OtherPlayersResolver();
        public static IReadOnlyList<BodyPart> GetBodyParts(RemotePlayer player) => BodyPartsResolver(player);
        public static IDisposable TryConstrain(RemotePlayer player, BodyPart part) =>
            CreateStaticConstraintResolver(player, part);
    }
}
