// Reflection-based BoneMenu registration. BoneLib must be installed separately.
using System;
using System.Linq;
using System.Reflection;
using MelonLoader;
using UnityEngine;

namespace TimeStopHostStatic
{
    internal static class BoneMenuBridge
    {
        internal static bool TryRegister(Action toggle, Action resume)
        {
            try
            {
                Type manager = AppDomain.CurrentDomain.GetAssemblies()
                    .Select(a => a.GetType("BoneLib.BoneMenu.MenuManager", false))
                    .FirstOrDefault(t => t != null);
                if (manager == null) return false;
                object category = InvokeNamed(manager, null, "CreateCategory", "Time Stop Host", Color.yellow, null);
                if (category == null) return false;
                bool toggleOk = InvokeNamed(category.GetType(), category,
                    "CreateFunctionElement", "Toggle Time Stop", Color.yellow, toggle) != null;
                bool resumeOk = InvokeNamed(category.GetType(), category,
                    "CreateFunctionElement", "Resume Time", Color.white, resume) != null;
                return toggleOk && resumeOk;
            }
            catch (Exception ex)
            {
                MelonLogger.Warning("BoneMenu registration could not complete: " + ex.Message);
                return false;
            }
        }

        private static object InvokeNamed(Type type, object receiver, string methodName,
            string text, Color color, Action callback)
        {
            BindingFlags flags = BindingFlags.Public | (receiver == null ? BindingFlags.Static : BindingFlags.Instance);
            foreach (MethodInfo method in type.GetMethods(flags).Where(m => m.Name == methodName))
            {
                ParameterInfo[] p = method.GetParameters();
                if (p.Length < 2 || p[0].ParameterType != typeof(string)
                    || p[1].ParameterType != typeof(Color)) continue;
                object[] args = new object[p.Length];
                args[0] = text;
                args[1] = color;
                bool usedCallback = callback == null;
                bool fits = true;
                for (int i = 2; i < p.Length; i++)
                {
                    if (callback != null && !usedCallback && p[i].ParameterType == typeof(Action))
                    {
                        args[i] = callback;
                        usedCallback = true;
                    }
                    else if (p[i].IsOptional) args[i] = p[i].DefaultValue;
                    else { fits = false; break; }
                }
                if (!fits || !usedCallback) continue;
                object result = method.Invoke(receiver, args);
                return method.ReturnType == typeof(void) ? (object)true : result;
            }
            return null;
        }
    }
}
