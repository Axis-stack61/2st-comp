# Time Stop Host — sequential Static Constrainer prototype v0.3

**STATUS: SOURCE PROTOTYPE; NOT A WORKING DLL.** The BONELAB/Fusion-specific adapter has not been implemented or verified. The code does not currently freeze other players and does not yet include VFX, audio, or world-object freezing. BoneMenu registration is a reflection-based attempt that may need adjustment for the installed BoneLib version.

## Constraint scheduling (requested four-per-second limit)

- Activation: right-hand grip + primary button; desktop F7 fallback; BoneMenu toggle / resume if registration succeeds.
- Only the verified Fusion host can begin the ability. Snapshot *remote* players in Fusion's returned order; finish **every relevant body part of player 1** before starting player 2, then player 3, and so on.
- Create **one** replicated base-game Static constraint every **0.26 seconds or slower**. The limiter is global, not per player. The adapter operation must create exactly one constraint and return an individually removable handle; no bulk constraint creation. Normal constraint removals follow the same global limit, including after an early cancellation.
- The six-second hold begins only after the final player's final constraint is created. Early toggle queues sequential release of constraints already applied, in reverse creation order. The next activation is blocked until release completes and a five-second cooldown elapses.
- If a creation fails, queue cleanup rather than continuing to the next player. Removal attempts are retried at most three times. A failed removal is explicitly logged, not silently treated as successful. Host-loss cleanup is best-effort and may depend on actual Fusion networking/authority.
- On plugin unload, cleanup must be attempted immediately because no further update frames are guaranteed. This emergency fallback **cannot guarantee the four-per-second removal limit**.
- A player who joins after activation is not included in this stop. A departing player or object loss during the sequence depends on the actual Fusion adapter and its removal semantics; test these cases.

**Example:** six body-part constraints for player A and four for player B require ten operations at 0.26-second spacing. A's six are created first, then B's four. The six-second timer starts upon creation of B's fourth constraint; releasing ten constraints takes additional time, subject to rate limiting.

## Files

- `Source/TimeStopMod.cs`: sequential scheduler, host check, controls, cooldown, release queue and error handling.
- `Source/FusionStaticAdapter.cs`: **unimplemented** version-specific host/player/body-part enumeration and per-constraint creation boundary.
- `Source/BoneMenuBridge.cs`: attempts to register BoneMenu controls.
- `TimeStopHostStatic.csproj`: project shell expecting matching local references under `References/`.

## Build requirements

1. Provide the matching installed BONELAB, Fusion, BoneLib and MelonLoader versions, and inspect the game assembly implementing the actual Static Constrainer and its Fusion replication. Confirm legal player body targets and whether unmodded remote clients actually honor restraints.
2. Install the Fusion adapter's four callbacks: `IsHostResolver`, `OtherPlayersResolver`, `BodyPartsResolver`, and `CreateStaticConstraintResolver`. The last MUST create exactly one synchronized Static constraint per call, leaving no partially created constraint if it fails, and return a handle that destroys exactly that constraint.
3. Supply `MelonLoader.dll`, `UnityEngine.CoreModule.dll`, `UnityEngine.InputLegacyModule.dll`, and `UnityEngine.XRModule.dll` from the correct runtime under `References/`; adjust framework/references to the installed version. Then run `dotnet build -c Release` from the project directory.
4. Test with consenting players in a private lobby. Verify actual constraint creation, synchronization, player locomotion, tracking, four-per-second rate, partial cancellation, host loss and release behavior. A constraint that replicates between players does not alone prove an unmodded player's own locomotion will be locked.
