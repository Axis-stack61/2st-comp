# Time Stop Host Static — local Windows build helper.
# This script DOES NOT invent or supply Fusion restraint logic.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$refs = Join-Path $root 'References'
$expected = @(
    'MelonLoader.dll',
    'UnityEngine.CoreModule.dll',
    'UnityEngine.InputLegacyModule.dll',
    'UnityEngine.XRModule.dll'
)
Write-Host 'Time Stop Host Static / build prerequisites' -ForegroundColor Cyan
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    Write-Error 'Missing .NET SDK (dotnet). Install an SDK that supports the target framework in TimeStopHostStatic.csproj.'
    exit 1
}
$missing = @($expected | Where-Object { -not (Test-Path -LiteralPath (Join-Path $refs $_) -PathType Leaf) })
if ($missing.Count -gt 0) {
    Write-Host 'Missing game-specific references in References/:' -ForegroundColor Yellow
    $missing | ForEach-Object { Write-Host "  $_" }
    Write-Host 'Use the matching DLLs from your installed BONELAB/MelonLoader game runtime; do not mix versions.'
    exit 2
}
$adapter = Get-Content (Join-Path $root 'Source/FusionStaticAdapter.cs') -Raw
if ($adapter -match 'public static Func<RemotePlayer, BodyPart, IDisposable> CreateStaticConstraintResolver;' -and
    $adapter -notmatch 'CreateStaticConstraintResolver\s*=') {
    Write-Host 'STOP: FusionStaticAdapter is not implemented. A DLL built from this source cannot freeze players.' -ForegroundColor Yellow
    Write-Host 'The source needs version-matched Fusion Static Constrainer create/delete logic before deployment.'
    exit 3
}
& dotnet build (Join-Path $root 'TimeStopHostStatic.csproj') -c Release
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host 'Build completed. Do not treat a successful compile as a successful in-game test.' -ForegroundColor Green
