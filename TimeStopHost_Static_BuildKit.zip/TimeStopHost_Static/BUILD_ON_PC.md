# Building for PCVR BONELAB

BoneLib is a dependency/API, **not a compiler or a game runtime**. The current project uses a MelonLoader entry point and targets .NET 6 as a **placeholder**; set the framework to the one required by *your installed versions*. MelonLoader and the IL2CPP interop/generated Unity assemblies must match your game. This zip intentionally contains no proprietary game libraries.

**Important:** `Source/FusionStaticAdapter.cs` has four unresolved integration callbacks. The project will NOT constrain actual Fusion players, even if its C# successfully compiles. The `build.ps1` script stops while the constraint-creation callback is unimplemented. You must use validated APIs to create one network-replicated Static constraint and return a handle for removing precisely that constraint, and resolve host/player/body objects. Follow Fusion server player-constraint permissions.

1. Inspect your actual installed Fusion version and BONELAB game assemblies to implement `FusionStaticAdapter` rather than guessing class names.
2. Place matching `MelonLoader.dll`, `UnityEngine.CoreModule.dll`, `UnityEngine.InputLegacyModule.dll`, and `UnityEngine.XRModule.dll` in `References/` (adjust project references according to your game's generated assemblies). BoneLib and Fusion may be added as explicit references once actual APIs are implemented.
3. Install a compatible .NET SDK for Windows, then run `powershell -ExecutionPolicy Bypass -File .\build.ps1` from this project folder.
4. When compiled **and tested**, install only the generated mod DLL under `BONELAB\Mods`. Do not install this source ZIP into the game.

Existing scheduler: starts with player 1, processes each required body part at 0.26-second intervals, then proceeds to the next player; begins the six-second hold after applying the final constraint; releases its own restraints in reverse order and observes a five-second cooldown. This scheduler has not been tested with Fusion.
